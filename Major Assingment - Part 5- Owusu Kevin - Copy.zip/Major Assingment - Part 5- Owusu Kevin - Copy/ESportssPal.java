// **********************************************************************************
// Title:Sports Pal
// Author: Kevin Owusu
// Course Section: CMIS201-SEC# (Seidel) Spring 2024
// File: Major Assingment - Part 5- Owusu Kevin -
// Description: A versatile tool for managing sports teams and players, now enhanced with the ability to track and manage player attributes// **********************************************************************************
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ESportssPal extends Application {

    private List<Team> teams;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Initialize teams list with data from teams.txt
        teams = initializeTeams();

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(20));

        // Team selection controls
        VBox teamControls = new VBox(10);
        Label teamLabel = new Label("Select Team:");
        ComboBox<Team> teamComboBox = new ComboBox<>();
        teamComboBox.getItems().addAll(teams);

        Button viewButton = new Button("View Players");
        viewButton.setOnAction(event -> {
            Team selectedTeam = teamComboBox.getValue();
            if (selectedTeam != null) {
                displayPlayers(selectedTeam);
            } else {
                showErrorAlert("Please select a team.");
            }
        });

        Button addButton = new Button("Add Player");
        addButton.setOnAction(event -> {
            Team selectedTeam = teamComboBox.getValue();
            if (selectedTeam != null) {
                addPlayer(selectedTeam);
            } else {
                showErrorAlert("Please select a team.");
            }
        });

        Button removeButton = new Button("Remove Player");
        removeButton.setOnAction(event -> {
            Team selectedTeam = teamComboBox.getValue();
            if (selectedTeam != null) {
                removePlayer(selectedTeam);
            } else {
                showErrorAlert("Please select a team.");
            }
        });

        teamControls.getChildren().addAll(teamLabel, teamComboBox, viewButton, addButton, removeButton);

        // Formation tab
        TabPane tabPane = new TabPane();
        Tab formationTab = new Tab("Formation");

        // Adding the soccer field image
        ImageView soccerField = new ImageView(new Image("https://cdn.discordapp.com/attachments/1003881934851690606/1238279882757247017/image.png?ex=663eb582&is=663d6402&hm=ef4c9da08c16f486d9604335aec972df56af3c5115abefff1dc43d69e61870b4&"));
        StackPane stackPane = new StackPane();
        stackPane.getChildren().add(soccerField);
        formationTab.setContent(stackPane);

        tabPane.getTabs().add(formationTab);

        root.setLeft(teamControls);
        root.setCenter(tabPane);

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Enhanced SportsPal");
        primaryStage.show();
    }

    private List<Team> initializeTeams() {
        // Create teams list and add data from teams.txt
        List<Team> teams = new ArrayList<>();
        String teamData = "Team A,Coach Smith,John Doe:25:Forward,Mary Johnson:23:Goalkeeper\n" +
                "Frederick Kings,Coach Brown,Michael Smith:24:Defender,Alice Williams:22:Midfielder\n" +
                "Frederick Skyline FC,Coach Johnson,David Wilson:27:Forward,Samantha Miller:26:Goalkeeper";

        String[] lines = teamData.split("\n");
        for (String line : lines) {
            String[] data = line.split(",");
            String teamName = data[0];
            String coachName = data[1];
            Team team = new Team(teamName, coachName);
            for (int i = 2; i < data.length; i++) {
                String[] playerData = data[i].split(":");
                String playerName = playerData[0];
                int playerAge = Integer.parseInt(playerData[1]);
                String playerPosition = playerData[2];
                Player player = new Player(playerName, playerAge, playerPosition);
                team.addPlayer(player);
            }
            teams.add(team);
        }
        return teams;
    }

    private void displayPlayers(Team team) {
        Map<String, List<Player>> playersByPosition = new HashMap<>();
        for (Player player : team.getPlayers()) {
            playersByPosition.computeIfAbsent(player.getPosition(), k -> new ArrayList<>()).add(player);
        }

        VBox playerInfoContainer = new VBox(10);
        playerInfoContainer.setPadding(new Insets(10));

        for (Map.Entry<String, List<Player>> entry : playersByPosition.entrySet()) {
            Label positionLabel = new Label(entry.getKey() + ":");
            playerInfoContainer.getChildren().add(positionLabel);
            for (Player player : entry.getValue()) {
                HBox playerBox = new HBox(10);
                Label playerLabel = new Label(player.toString());

                // Button for adding attribute
                Button addAttributeButton = new Button("Add Attribute");
                addAttributeButton.setOnAction(event -> addAttribute(player));

                // Button for removing attribute
                Button removeAttributeButton = new Button("Remove Attribute");
                removeAttributeButton.setOnAction(event -> removeAttribute(player));

                playerBox.getChildren().addAll(playerLabel, addAttributeButton, removeAttributeButton);
                playerInfoContainer.getChildren().add(playerBox);
            }
        }

        ScrollPane scrollPane = new ScrollPane(playerInfoContainer);
        scrollPane.setFitToWidth(true);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Players of " + team.getName());
        alert.setHeaderText(null);
        alert.getDialogPane().setContent(scrollPane);
        alert.showAndWait();
    }

    private void addAttribute(Player player) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add Attribute");
        dialog.setHeaderText("Enter attribute:");
        dialog.setContentText("Attribute:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(attribute -> {
            player.addAttribute(attribute);
            displayPlayers(player.getTeam()); // Refresh player display after adding attribute
        });
    }

    private void removeAttribute(Player player) {
        ChoiceDialog<String> dialog = new ChoiceDialog<>(null, player.getAttributes());
        dialog.setTitle("Remove Attribute");
        dialog.setHeaderText("Select attribute to remove:");
        dialog.setContentText("Attribute:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(attribute -> {
            player.removeAttribute(attribute);
            displayPlayers(player.getTeam()); // Refresh player display after removing attribute
        });
    }

    private void addPlayer(Team team) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add Player");
        dialog.setHeaderText("Enter player details (Name, Age and Position");
        dialog.setContentText("Player:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(playerInfo -> {
            String[] data = playerInfo.split(":");
            if (data.length == 3) {
                String playerName = data[0];
                int playerAge;
                try {
                    playerAge = Integer.parseInt(data[1]);
                } catch (NumberFormatException e) {
                    showErrorAlert("Invalid age. Please enter a valid number for age.");
                    return;
                }
                String playerPosition = data[2];
                Player player = new Player(playerName, playerAge, playerPosition);
                team.addPlayer(player);
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                successAlert.setTitle("Success");
                successAlert.setHeaderText(null);
                successAlert.setContentText("Player added successfully.");
                successAlert.showAndWait();
            } else {
                showErrorAlert("Invalid player details. Please enter name, age, and position separated by colon (:).");
            }
        });
    }

    private void removePlayer(Team team) {
        ChoiceDialog<Player> dialog = new ChoiceDialog<>(null, team.getPlayers());
        dialog.setTitle("Remove Player");
        dialog.setHeaderText("Select player to remove:");
        dialog.setContentText("Player:");

        Optional<Player> result = dialog.showAndWait();
        result.ifPresent(player -> {
            team.removePlayer(player);
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Success");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Player removed successfully.");
            successAlert.showAndWait();
        });
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

class Team {

    private String name;
    private String coach;
    private List<Player> players;

    public Team(String name, String coach) {
        this.name = name;
        this.coach = coach;
        players = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void removePlayer(Player player) {
        players.remove(player);
    }

    public List<Player> getPlayers() {
        return players;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}

class Player {
    private String name;
    private int age;
    private String position;
    private List<String> attributes;

    public Player(String name, int age, String position) {
        this.name = name;
        this.age = age;
        this.position = position;
        this.attributes = new ArrayList<>();
    }

    public void addAttribute(String attribute) {
        attributes.add(attribute);
    }

    public void removeAttribute(String attribute) {
        attributes.remove(attribute);
    }

    public List<String> getAttributes() {
        return attributes;
    }

    public Team getTeam() {
        // Assuming each player belongs to a team
        // You might need to adjust this method based on your actual implementation
        // For example, you might need to pass the team as a parameter in the Player constructor
        // or set it using a separate method.
        // This is just a placeholder to demonstrate the functionality.
        return null;
    }

    public String getPosition() {
        return position;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(name).append("/").append(age).append("yrs/").append(position);
        if (!attributes.isEmpty()) {
            stringBuilder.append(" Attributes: ").append(attributes);
        }
        return stringBuilder.toString();
    }
}
